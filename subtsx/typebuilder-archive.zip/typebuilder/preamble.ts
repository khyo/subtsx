

import * as _voby from 'si/voby'

declare global {
  const voby: typeof _voby;
}
